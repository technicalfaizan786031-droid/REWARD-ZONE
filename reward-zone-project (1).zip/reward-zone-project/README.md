# Reward Zone — Firebase-backed starter

This mobile-friendly website uses an admin-managed code inventory. The public page does **not** invent codes: the callable backend issues one pre-added code matching both reward type and amount, and marks it used. This starter is not deployed/configured until you complete the steps below.

## 1. Create Firebase project
1. Open https://console.firebase.google.com and create a project.
2. In **Authentication → Sign-in method**, enable **Email/Password**.
3. In **Authentication → Users**, add your admin email and set a strong password.
4. In **Project settings → General → Your apps**, register a Web app and copy its Firebase config.
5. In **Firestore Database**, create a database.

## 2. Configure the website
In `index.html`, replace these values in `firebaseConfig`:
- `PASTE_FIREBASE_WEB_API_KEY`
- `PASTE_PROJECT_ID` (in `authDomain` and `projectId`)
- `PASTE_FIREBASE_APP_ID`

Firebase web config is not a secret. Never put a service-account private key in the HTML.

## 3. Set admin UID and rules
1. In Firebase Authentication → Users, copy the admin user's **UID**.
2. Replace `PASTE_ADMIN_USER_UID` in `firestore.rules` with that UID.
3. Deploy the rules (Firebase CLI required): `firebase deploy --only firestore:rules`.

## 4. Deploy the secure function
Install Node.js and Firebase CLI on a computer, then from this project folder run:
1. `firebase login`
2. `firebase use --add` and select your project
3. `cd functions && npm install && cd ..`
4. `firebase deploy --only functions`

Firebase may require the project to be on the Blaze plan for Cloud Functions; check Firebase's current billing requirements before deploying. Set a budget alert.

## 5. Publish on GitHub Pages
Upload `index.html` to the root of your GitHub Pages repository. Keep `functions/`, `firestore.rules`, `firebase.json`, and this README for Firebase setup/deployment.

## Add codes
Open the website → **Admin** → log in → enter the exact code, choose reward type, enter matching amount 1–500 → Add Code. A visitor must choose the same reward type and amount to receive that code. Each code is issued once.

## Important
Only add codes you own or are authorized to distribute. The site does not create valid Google Play or Free Fire codes; redemption validity comes from the issuer. Configure Firebase before use: until config and function are deployed, generation/admin features will not work.
