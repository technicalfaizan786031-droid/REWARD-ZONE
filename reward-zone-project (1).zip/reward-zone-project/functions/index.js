const { onCall, HttpsError } = require('firebase-functions/v2/https');
const { initializeApp } = require('firebase-admin/app');
const { getFirestore, FieldValue } = require('firebase-admin/firestore');
initializeApp();
const db = getFirestore();
exports.generateCode = onCall({ region: 'us-central1', maxInstances: 10, enforceAppCheck: false }, async (request) => {
  const { reward, amount } = request.data || {};
  if (!['playstore', 'diamonds'].includes(reward) || !Number.isInteger(amount) || amount < 1 || amount > 500) {
    throw new HttpsError('invalid-argument', 'Choose a valid reward and amount from 1 to 500.');
  }
  const q = db.collection('codes').where('reward', '==', reward).where('amount', '==', amount).where('status', '==', 'available').limit(50);
  const snap = await q.get();
  if (snap.empty) throw new HttpsError('not-found', 'No matching code is available.');
  // Pick from current candidates; transaction prevents the same code being issued twice.
  const candidates = snap.docs.sort(() => Math.random() - 0.5);
  for (const doc of candidates) {
    try {
      const code = await db.runTransaction(async tx => {
        const fresh = await tx.get(doc.ref);
        if (!fresh.exists || fresh.data().status !== 'available') return null;
        tx.update(doc.ref, { status: 'used', usedAt: FieldValue.serverTimestamp() });
        return fresh.data().code;
      });
      if (code) return { code };
    } catch (e) { /* try another available candidate */ }
  }
  throw new HttpsError('not-found', 'No matching code is available. Please try again.');
});
